package view;

public interface OnScheduleListener {
	
	void onActionSchedule(String cName, String cHour, String date);
	void onDeleteSchedule();
		
}
